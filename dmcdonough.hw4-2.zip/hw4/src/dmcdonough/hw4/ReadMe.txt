Daniel McDonough
HW4
Written Questions

Evaluating Binary Trees:
-------------------------
A)
Formula:((1.0 + (sqrt 5.0)) / 2.0)
1.618033988749895

B)
Formula:(4.0 + ((triangle 12.0) * pi))
44.840704496667314

C)
Formula:(((3.0 * 4.0) + (8.0 ^ 3.0)) / ((2.0 - 1.0) * (sqrt 7.0)))
198.05338385683507